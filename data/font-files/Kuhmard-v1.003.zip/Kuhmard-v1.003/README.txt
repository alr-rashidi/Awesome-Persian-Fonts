کوهمرد · Kuhmard
نسخهٔ ۱٫۰۰۳ · Version 1.003
Azrast · azrast.com

────────────────────────────────────────

فارسی

کوهمرد نویسه‌ای فارسی با پایه‌های چهارگوش است که لاتینِ هماهنگِ خودش را دارد؛ نخستین نویسهٔ از راست (Azrast).
یک وزن (سیاه، Bold) · فارسی و عربی (همراه حروف اردوی ٹ ڈ ڑ ے) و لاتین.

آنچه در این بسته هست:
  fonts/otf/Kuhmard-Bold.otf      برای نصب روی رایانه
  fonts/web/Kuhmard-Bold.woff2    برای وبسایت
  signs/                          هشت نشانهٔ کوهمرد (SVG)
  OFL.txt                         متن مجوز

نصب:
  مک: روی فایل Kuhmard-Bold.otf دو بار کلیک کنید، سپس دکمهٔ «Install Font» را بزنید.
  ویندوز: روی فایل راست‌کلیک کنید و «Install» را انتخاب کنید.

استفاده در وب:
  @font-face {
    font-family: "Kuhmard";
    src: url("Kuhmard-Bold.woff2") format("woff2");
    font-weight: 700;
    font-display: swap;
  }

مجوز:
کوهمرد با مجوز آزاد SIL Open Font License 1.1 منتشر شده است و استفاده از آن در هر کاری، شخصی یا تجاری، رایگان است.
می‌توانید آن را تغییر دهید و منتشر کنید، به شرط آنکه نسخهٔ تغییریافته هم با همین مجوز منتشر شود. فروشِ جداگانهٔ خودِ فایل‌های فونت مجاز نیست.
نشانه‌های پوشهٔ signs هم در هر کاری، شخصی یا تجاری، رایگان‌اند.

تیم:
  علی تقی‌پور        هم‌بنیان‌گذار و مدیر فنی
  علی شیردستیان      هم‌بنیان‌گذار و مدیر طراحی
  فاطمه چراغی        طراح ارشد حروف
  فاطمه بلوکی        طراح حروف

شکل حروف بر پایهٔ حروف‌نگاری سومین جشنوارهٔ جهانی فیلم تهران (۱۳۵۳) طراحی شده است.
حروف لاتین، عددها و نشانه‌ها از نویسهٔ آزاد Rokkitt (با مجوز SIL Open Font License 1.1) برگرفته شده‌اند.

با کوهمرد چیزی بسازید و نشان‌مان دهید: info@azrast.com

────────────────────────────────────────

English

Kuhmard is a Persian slab serif with its own matching Latin, the first typeface from Azrast.
One weight (Bold) · Persian and Arabic (with the Urdu letters ٹ ڈ ڑ ے) and Latin.

In this package:
  fonts/otf/Kuhmard-Bold.otf      to install on your computer
  fonts/web/Kuhmard-Bold.woff2    for websites
  signs/                          the eight Kuhmard signs (SVG)
  OFL.txt                         the licence

Install:
  Mac: double-click Kuhmard-Bold.otf, then click "Install Font".
  Windows: right-click the file, then click "Install".

On the web:
  @font-face {
    font-family: "Kuhmard";
    src: url("Kuhmard-Bold.woff2") format("woff2");
    font-weight: 700;
    font-display: swap;
  }

Licence:
Kuhmard is released under the SIL Open Font License 1.1. It is free to use in any project, personal or commercial.
You may change it and share it under the same licence. You may not sell the font files on their own.
The signs in the signs folder are free to use in any project, personal or commercial.

Team:
  Aly Taghipour     Co-founder & Technical Director
  Ali Shirdastian   Co-founder & Design Director
  Fateme Cheraghi   Lead Type Designer
  Fateme Bluekey    Type Designer

Letterforms after the lettering of the 3rd Tehran International Film Festival (1974).
Latin letters, digits and signs adapted from Rokkitt (SIL Open Font License 1.1).

Make something with Kuhmard and show us: info@azrast.com
