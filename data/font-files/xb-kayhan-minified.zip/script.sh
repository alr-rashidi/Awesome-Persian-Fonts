FILES=('XB KayhanBdIt'
'XB KayhanBd'
'XB KayhanIt'
'XB KayhanNavaar'
'XB KayhanPook'
'XB KayhanSayeh'
'XB Kayhan')

for NAME in "${FILES[@]}"
do
    ttx -x TSIV -x feat -x just -x kern -x morx -x prop "$NAME.ttf"
    rm "$NAME.ttf"
    ttx "$NAME.ttx"
    woff2_compress "$NAME.ttf"
    rm "$NAME.ttx"
done